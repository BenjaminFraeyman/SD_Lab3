﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_1
{
    class Lichtpunt
    {   
        public string  Naam { get; private set; }
        public string Toestand { get; private set; }

        public Lichtpunt(string naam, string toestand) // constructor
        {   
            Toestand = toestand;
            Naam = naam;
        }
        public override string ToString()
        {
            return Naam + " - " + Toestand;
        }

        public void ChangeValue(string toe, Lichtpunt licht)
        {
            licht.Toestand = toe;
            Console.WriteLine("value changed: " + licht);
        }

        public static void Display(List<Lichtpunt> lichten)
        {
            foreach (Lichtpunt licht in lichten)
            {
                if (licht is Multilichtpunt)
                {
                    Multilichtpunt temp = (Multilichtpunt)licht;
                    temp.MultiDisplay(temp);
                }
                else
                { Console.WriteLine(licht); }
            }
        }
    }
}
