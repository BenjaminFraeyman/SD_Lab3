﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_1
{
    class RGBlichtpunt : Dimbaarlichtpunt
    {
        public string Kleur { get; private set; } // welk kleur
        public RGBlichtpunt(string naam, string toestand, int percent, string kleur) : base(naam, toestand, percent)
        {
            Kleur = kleur;
        }
        public override string ToString()
        {
            return Naam + " - " + Toestand + " - " + Percentage + " - " + Kleur;
        }

        public void veranderkleur(RGBlichtpunt licht, string kleur)
        {
            licht.Kleur = kleur;
            Console.WriteLine("value changed: " + licht);
        }
    }
}
