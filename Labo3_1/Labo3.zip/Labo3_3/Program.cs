﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Labo3_3
{
    enum Hoofdmenu { Nieuw = 1, Gooi = 2, Stoppen = 3 }; // om de keuze te verbinden met de tekst van het menu
    enum DiceType { NormalDice = 1, Magicdice = 2, Supermagicdice = 3 };   
    class Program
    {
        static void Main(string[] args)
        {
            // default waardes // worden tijdens het uitvoeren van het programma toch uitgevoerd
            Dice dice = DiceFactory.CreateDice(DiceType.NormalDice, 6);
            Boolean Continue = true;
            int Throw = 0;
            int Keuze2 = 0;
            // --------------

            while (Continue) // stoppen enkel door keuze Stoppen
            {
                Console.WriteLine("1: Nieuw spel");
                Console.WriteLine("2: Gooi");
                Console.WriteLine("3: Stoppen");
                int Keuze1 = Convert.ToInt32(Console.ReadLine());

                if (Keuze1 == (int)Hoofdmenu.Nieuw) // nieuw spel starten
                {
                    Console.WriteLine();
                    Console.WriteLine("1: NormalDice");
                    Console.WriteLine("2: MagicDice");
                    Console.WriteLine("3: SuperMagicDice");
                    Console.WriteLine("4: Random");
                    Keuze2 = Convert.ToInt32(Console.ReadLine());
                    while (Keuze2 == 4) // random dice kiezen
                    {
                        Random random = new Random();
                        Keuze2 = random.Next(1, 4);
                    }

                    Console.WriteLine("Aantal vlakken?"); // aantal vlakken opgeven
                    int Vlakken = Convert.ToInt32(Console.ReadLine());
                    DiceType type = (DiceType)Keuze2; // type van dobbelsteen = de dobbelsteen die overeenkomt met het nummer van keuze2
                    dice = DiceFactory.CreateDice(type, Vlakken);
                }

                if (Keuze1 == (int)Hoofdmenu.Gooi) // keuze gooi werd gemaakt
                {
                    Throw = dice.ThrowDice();
                }

                if (Keuze1 == (int)Hoofdmenu.Stoppen) // keuze stoppen werd gemaakt
                { Continue = false; }
                Console.WriteLine();
                Console.WriteLine();
            }
        }
    }
}
// benodigde tijd : 8uren (voor practicum)