﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Labo3_3
{   
    class DiceFactory
    {
        public static Dice CreateDice(DiceType type, int zijden)
        {
            if (type == DiceType.NormalDice)
            { return new NormalDice(zijden); }

            else if (type == DiceType.Magicdice)
            { return new Magicdice(zijden); }

            else
            { return new Supermagicdice(zijden); }
        }
    }
}