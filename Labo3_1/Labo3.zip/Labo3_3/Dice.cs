﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_3
{
    abstract class Dice
    {
        public int Zijden { get; set; }
        public Dice(int zijden) // constructor
        {
            Zijden = zijden;
        }
        public abstract int ThrowDice();
    }
}