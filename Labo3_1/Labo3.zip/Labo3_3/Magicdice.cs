﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_3
{
    class Magicdice : Dice
    {
        Random random = new Random();
        public int Worpcounter { get; private set; }
        public int Aantal { get; private set; }
        public Magicdice(int zijden) : base(zijden)// constructor
        {
            Aantal = zijden; // gebruikt om na 3 worpen de zijden weer op het begin te zetten
            Worpcounter = 0; // gebruikt om het aantal worpen bij te houden
        }

        public override int ThrowDice()
        {
            int Throw = random.Next(1, (Zijden + 1)); 
            if (Throw == Zijden)
            {
                int temp = Zijden * 2;
                Zijden = temp;
                Worpcounter = 0;
            }
            if (Worpcounter == 3)
            { Zijden = Aantal; }
            Worpcounter++;
            Console.WriteLine("U wierp: {0} (zijden: {1})", Throw, Zijden);
            return Throw;
        }

        public override string ToString()
        { return Convert.ToString(Zijden); }
    }
}